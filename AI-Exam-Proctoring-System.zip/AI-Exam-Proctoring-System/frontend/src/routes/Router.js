import React, { lazy } from 'react';
import { Navigate, Route, createBrowserRouter, createRoutesFromElements } from 'react-router-dom';
import Loadable from '../layouts/full/shared/loadable/Loadable';
import { useSelector } from 'react-redux';

/* ***Layouts**** */
const BlankLayout = Loadable(lazy(() => import('../layouts/blank/BlankLayout')));
const FullLayout = Loadable(lazy(() => import('../layouts/full/FullLayout')));
const ExamLayout = Loadable(lazy(() => import('../layouts/full/ExamLayout')));

/* ****Pages***** */
// const Dashboard = Loadable(lazy(() => import('../views/dashboard/Dashboard')));
const SamplePage = Loadable(lazy(() => import('../views/sample-page/SamplePage')));
const Success = Loadable(lazy(() => import('../views/Success')));

// const Icons = Loadable(lazy(() => import('../views/icons/Icons')));
// const TypographyPage = Loadable(lazy(() => import('../views/utilities/TypographyPage')));
// const Shadow = Loadable(lazy(() => import('../views/utilities/Shadow')));
//Student Routes

const TestPage = Loadable(lazy(() => import('./../views/student/TestPage')));
const ExamPage = Loadable(lazy(() => import('./../views/student/ExamPage')));
const StudentDashboard = Loadable(lazy(() => import('./../views/student/StudentDashboard')));
const ExamDetails = Loadable(lazy(() => import('./../views/student/ExamDetails')));
const CodeDetails = Loadable(lazy(() => import('../views/student/CodeDetails')));
const ResultPage = Loadable(lazy(() => import('./../views/student/ResultPage')));
const Coder = Loadable(lazy(() => import('../views/student/Coder')));
const ProctoringReport = Loadable(lazy(() => import('../views/student/ProctoringReport')));
//Auth Routes
const Error = Loadable(lazy(() => import('../views/authentication/Error')));
const Register = Loadable(lazy(() => import('../views/authentication/Register')));
const Login = Loadable(lazy(() => import('../views/authentication/Login')));
const UserAccount = Loadable(lazy(() => import('../views/authentication/UserAccount')));
const UserProfilePage = Loadable(lazy(() => import('../views/user/UserProfilePage')));
const UserTasksPage = Loadable(lazy(() => import('../views/user/UserTasksPage')));

// Teacher Routes
const TeacherExamsPage = Loadable(lazy(() => import('./../views/teacher/TeacherExamsPage')));
const CreateExamPage = Loadable(lazy(() => import('./../views/teacher/CreateExamPage')));
const ExamLogPage = Loadable(lazy(() => import('./../views/teacher/ExamLogPage')));
const AddQuestions = Loadable(lazy(() => import('./../views/teacher/AddQuestions')));
const PrivateRoute = Loadable(lazy(() => import('src/views/authentication/PrivateRoute')));
const TeacherRoute = Loadable(lazy(() => import('src/views/authentication/TeacherRoute')));
const UserApprovalsPage = Loadable(lazy(() => import('src/views/teacher/UserApprovalsPage')));

// New Teacher Dashboard & Proctoring Routes
const AdminDashboard = Loadable(lazy(() => import('./../views/teacher/AdminDashboard')));
const AnalyticsPage = Loadable(lazy(() => import('./../views/teacher/AnalyticsPage')));
const LiveMonitoringPage = Loadable(lazy(() => import('./../views/teacher/LiveMonitoringPage')));

// Common/Student Routes
// Role-based Root Redirect
const RoleBasedRedirect = () => {
  const { userInfo } = useSelector((state) => state.auth);
  if (!userInfo) {
    return <Navigate to="/auth/login" replace />;
  }
  const role = (userInfo.role || '').toLowerCase();
  if (role.includes('teacher') || role.includes('admin')) {
    return <Navigate to="/admin-dashboard" replace />;
  }
  return <Navigate to="/dashboard" replace />;
};

const Router = createBrowserRouter(
  createRoutesFromElements(
    // Every router we create will now go in here as
    // they going to be child of our main App component
    <>
      {/* Root lands on role-based dashboard for logged in users, or login for guests */}
      <Route path="/" element={<RoleBasedRedirect />} />

      {/* // Private Routes */}
      <Route path="" element={<PrivateRoute />}>
        {/* // Main layout */}
        <Route element={<FullLayout />}>
          <Route path="/dashboard" exact={true} element={<StudentDashboard />} />
          <Route path="/sample-page" exact={true} element={<SamplePage />} />
          <Route path="/Success" exact={true} element={<Success />} />
          <Route path="/exam" exact={true} element={<ExamPage />} />
          <Route path="/result" exact={true} element={<ResultPage />} />
          <Route path="/profile" exact={true} element={<UserProfilePage />} />
          <Route path="/account" exact={true} element={<UserAccount />} />
          <Route path="/tasks" exact={true} element={<UserTasksPage />} />
          <Route path="/user/profile" exact={true} element={<UserProfilePage />} />
          <Route path="/user/account" exact={true} element={<UserAccount />} />
          <Route path="/user/tasks" exact={true} element={<UserTasksPage />} />
          <Route path="" element={<TeacherRoute />}>
            <Route path="/teacher/exams" exact={true} element={<TeacherExamsPage />} />
            <Route path="/create-exam" exact={true} element={<CreateExamPage />} />
            <Route path="/add-questions" exact={true} element={<AddQuestions />} />
            <Route path="/exam-log" exact={true} element={<ExamLogPage />} />
            <Route path="/user-approvals" exact={true} element={<UserApprovalsPage />} />
            <Route path="/teacher/approvals" exact={true} element={<Navigate to="/user-approvals" replace />} />
            <Route path="/admin-dashboard" exact={true} element={<AdminDashboard />} />
            <Route path="/analytics" exact={true} element={<AnalyticsPage />} />
            <Route path="/live-monitoring" exact={true} element={<LiveMonitoringPage />} />
          </Route>
          <Route path="/student/exams" exact={true} element={<Navigate to="/exam" replace />} />
        </Route>
        <Route path="/" element={<ExamLayout />}>
          <Route path="exam/:examId" exact={true} element={<ExamDetails />} />
          <Route path="exam/:examId/codedetails" exact={true} element={<CodeDetails />} />
          <Route path="exam/:examId/:testId" exact={true} element={<TestPage />} />
          <Route path="exam/:examId/code" exact={true} element={<Coder />} />
          <Route path="exam/:examId/report/:sessionId" exact={true} element={<ProctoringReport />} />
        </Route>
      </Route>
      {/* User layout */}
      <Route path="/user" element={<FullLayout />}>
        <Route path="account" exact={true} element={<UserAccount />} />
      </Route>

      {/* Authentication layout */}
      <Route path="/auth" element={<BlankLayout />}>
        <Route path="404" element={<Error />} />
        <Route path="/auth/register" element={<Register />} />
        <Route path="/auth/login" element={<Login />} />
        {/* <Route path="*" element={<Navigate to="/auth/404" />} /> */}
      </Route>
    </>,
  ),
);

export default Router;
