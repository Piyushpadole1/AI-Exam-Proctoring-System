import os
import re

frontend_dir = r'D:\Mega Project 4th Year\AI-Exam-Proctoring-System\frontend\src'
output_path = r'D:\Mega Project 4th Year\AI-Exam-Proctoring-System\docs\audit\frontend-api-calls.md'

lines = []
lines.append("# Frontend API Calls Inventory\n")
lines.append("Comprehensive inventory of all frontend API calls (RTK Query endpoints & axiosInstance calls), their calling components, payloads, response handling, and targeted backend endpoints.\n")
lines.append("| Calling Component / File | HTTP Method | Target URL / Path | Payload / Query | Response Handling | Backend Target Endpoint |")
lines.append("|---|---|---|---|---|---|")

# 1. Scan RTK Query slices
slices_dir = os.path.join(frontend_dir, 'slices')
if os.path.exists(slices_dir):
    for fn in sorted(os.listdir(slices_dir)):
        if not fn.endswith('.js') and not fn.endswith('.jsx'):
            continue
        fp = os.path.join(slices_dir, fn)
        with open(fp, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()

        # Extract base URLs defined in slice
        url_constants = dict(re.findall(r'const\s+([A-Z_]+_URL)\s*=\s*[\'"`]([^\'"`]+)[\'"`]', content))

        # Match endpoints in builder
        ep_pattern = re.compile(
            r'(\w+):\s*builder\.(query|mutation)\(\{\s*query:\s*(?:\([^)]*\)\s*=>\s*)?\{?(.*?)\}\s*(?:,\s*pollingInterval:.*?)?\s*\}\)',
            re.DOTALL
        )

        for m in ep_pattern.finditer(content):
            ep_name = m.group(1)
            ep_type = m.group(2)
            block = m.group(3)

            # extract url
            url_match = re.search(r'url:\s*(?:`([^`]+)`|\'([^\']+)\'|"([^"]+)"|([A-Z_]+_URL\s*\+?\s*[^,\n\}]*))', block)
            raw_url = ''
            if url_match:
                raw_url = url_match.group(1) or url_match.group(2) or url_match.group(3) or url_match.group(4)
            
            # Resolve url constants
            for k, v in url_constants.items():
                if k in raw_url:
                    raw_url = raw_url.replace(f'${{{k}}}', v).replace(k, v)

            # extract method
            method_match = re.search(r'method:\s*[\'"`]([A-Z]+)[\'"`]', block)
            method = method_match.group(1) if method_match else ('GET' if ep_type == 'query' else 'POST')

            # extract body
            body_match = re.search(r'body:\s*([^,\n\}]+)', block)
            body_desc = body_match.group(1).strip() if body_match else 'None'

            lines.append(f"| `slices/{fn}` (`{ep_name}`) | `{method}` | `{raw_url}` | `{body_desc}` | Redux State / Hook cached | `{raw_url}` |")

# 2. Scan views and components for axiosInstance or fetch
for root, dirs, files in os.walk(frontend_dir):
    for fn in sorted(files):
        if not (fn.endswith('.js') or fn.endswith('.jsx')):
            continue
        # Skip slices since we parsed them
        if 'slices' in root:
            continue
        fp = os.path.join(root, fn)
        rel_path = os.path.relpath(fp, frontend_dir)
        with open(fp, 'r', encoding='utf-8', errors='ignore') as f:
            text = f.read()

        # Match axiosInstance.get/post/put/delete or axios.
        axios_pattern = re.compile(
            r'(?:axiosInstance|axios)\.(get|post|put|delete|patch)\(\s*(?:`([^`]+)`|\'([^\']+)\'|"([^"]+)")\s*(?:,\s*([^,\)]+))?',
            re.DOTALL
        )

        for m in axios_pattern.finditer(text):
            verb = m.group(1).upper()
            path = m.group(2) or m.group(3) or m.group(4)
            arg2 = m.group(5).strip() if m.group(5) else 'None'
            arg2 = re.sub(r'\s+', ' ', arg2)[:40]

            lines.append(f"| `{rel_path}` | `{verb}` | `{path}` | `{arg2}` | Local Component State / Toast | `{path}` |")

# Deduplicate rows
header = lines[:5]
data_rows = sorted(list(set(lines[5:])))
final_output = header + data_rows

with open(output_path, 'w', encoding='utf-8') as out:
    out.write('\n'.join(final_output))

print(f"Generated {len(data_rows)} frontend API calls in {output_path}")
