import os
import re

dir_path = r'D:\Mega Project 4th Year\AI-Exam-Proctoring-System\backend-spring\src\main\java\com\aieval8\examproctoring\controller'
output_path = r'D:\Mega Project 4th Year\AI-Exam-Proctoring-System\docs\audit\backend-endpoints.md'

controllers = sorted(os.listdir(dir_path))

lines = []
lines.append("# Backend Endpoints Inventory\n")
lines.append("Comprehensive audit inventory of all Spring Boot REST endpoints in `backend-spring`.\n")
lines.append("| HTTP Method | Endpoint Path | Role / Authorization | Controller Method | Payload / Parameters | Return Type | Status Codes |")
lines.append("|---|---|---|---|---|---|---|")

for fn in controllers:
    if not fn.endswith('.java'):
        continue
    fp = os.path.join(dir_path, fn)
    with open(fp, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()

    # Find class-level request mapping (must occur before 'public class')
    class_def_pos = content.find('public class')
    base_prefix = ''
    if class_def_pos != -1:
        header_text = content[:class_def_pos]
        class_match = re.search(r'@RequestMapping\s*\(\s*(?:value\s*=\s*)?\"([^\"]*)\"', header_text)
        if class_match:
            base_prefix = class_match.group(1).strip()
        body_content = content[class_def_pos:]
    else:
        body_content = content

    # Clean multi-line comments
    body_clean = re.sub(r'/\*.*?\*/', '', body_content, flags=re.DOTALL)

    # Find all mapping annotations inside the class body
    method_pattern = re.compile(
        r'(@(GetMapping|PostMapping|PutMapping|DeleteMapping|PatchMapping|RequestMapping)\s*\(((?:[^)(]+|\((?:[^)(]+|\([^)(]*\))*\))*)\))\s*'
        r'(?:@[\w]+(?:\(.*?\))?\s*)*'
        r'(?:public|protected|private)\s+([\w\<\>\[\],\s\?]+?)\s+(\w+)\s*\((.*?)\)',
        re.DOTALL
    )

    for m in method_pattern.finditer(body_clean):
        anno_type = m.group(2)
        raw_args = m.group(3).strip()
        ret_type = m.group(4).strip()
        method_name = m.group(5).strip()
        params = m.group(6).strip().replace('\n', ' ')

        # Determine HTTP Verb
        if anno_type == 'RequestMapping':
            verb_match = re.search(r'method\s*=\s*(?:RequestMethod\.)?([A-Z]+)', raw_args)
            verb = verb_match.group(1) if verb_match else 'ANY'
        else:
            verb = anno_type.replace('Mapping', '').upper()

        # Extract paths directly from raw_args
        paths = re.findall(r'\"([^\"]*)\"', raw_args)
        if not paths:
            paths = ['']

        # Determine required role
        role = "Public"
        p_lower = params.lower()
        m_lower = method_name.lower()
        r_lower = raw_args.lower()
        if "role_teacher" in p_lower or "teacher" in r_lower or "teacher" in m_lower or "createexam" in m_lower or "addquestion" in m_lower:
            role = "ROLE_TEACHER"
        elif "role_student" in p_lower or "student" in r_lower or "student" in m_lower:
            role = "ROLE_STUDENT"
        elif "admin" in r_lower or "role_admin" in p_lower:
            role = "ROLE_TEACHER / ROLE_ADMIN"
        elif "customuserdetails" in p_lower:
            role = "Authenticated User (JWT)"

        for raw_p in paths:
            if raw_p.startswith('application/') or raw_p.startswith('text/') or raw_p.startswith('image/'):
                continue
            
            p = raw_p
            full_path = base_prefix
            if p:
                if full_path.endswith('/') and p.startswith('/'):
                    full_path = full_path + p[1:]
                elif not full_path.endswith('/') and not p.startswith('/'):
                    full_path = full_path + '/' + p
                else:
                    full_path = full_path + p
            if not full_path:
                full_path = '/'
            if not full_path.startswith('/'):
                full_path = '/' + full_path

            # Payload description
            req_info = "None"
            if "@RequestBody" in params:
                rb_match = re.search(r'@RequestBody(?:\(.*?\))?\s+([\w\<\>\[\],\s\?]+)\s+(\w+)', params)
                req_info = f"Body: `{rb_match.group(1).strip() if rb_match else 'JSON'}`"
            if "@RequestParam" in params:
                params_found = re.findall(r'@RequestParam(?:\(.*?\))?\s+[\w\<\>\[\],\s\?]+\s+(\w+)', params)
                req_info += f" | Query: `{','.join(params_found)}`"
            if "@PathVariable" in params:
                path_vars = re.findall(r'@PathVariable(?:\(.*?\))?\s+[\w\<\>\[\],\s\?]+\s+(\w+)', params)
                req_info += f" | PathVar: `{','.join(path_vars)}`"

            ret_clean = ret_type.replace('ResponseEntity<', '').rstrip('>').replace('|', '\\|')
            lines.append(f"| `{verb}` | `{full_path}` | {role} | `{fn[:-5]}.{method_name}()` | {req_info} | `{ret_clean}` | 200, 400, 401, 403, 500 |")

# Sort and deduplicate rows
header = lines[:5]
# Filter out any non-path anomalies
valid_rows = []
for r in lines[5:]:
    parts = r.split('|')
    if len(parts) >= 3:
        path = parts[2].strip().strip('`')
        if re.match(r'^/[a-zA-Z0-9_\-\/{}]*$', path):
            valid_rows.append(r)

valid_rows = sorted(list(set(valid_rows)))
final_output = header + valid_rows

with open(output_path, 'w', encoding='utf-8') as out:
    out.write('\n'.join(final_output))

print(f"Generated {len(valid_rows)} clean endpoints in {output_path}")
