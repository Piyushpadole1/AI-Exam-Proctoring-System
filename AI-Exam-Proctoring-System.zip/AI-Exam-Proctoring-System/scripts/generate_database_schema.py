import os
import re

schema_sql_path = r'D:\Mega Project 4th Year\AI-Exam-Proctoring-System\backend-spring\src\main\resources\schema.sql'
entity_dir = r'D:\Mega Project 4th Year\AI-Exam-Proctoring-System\backend-spring\src\main\java\com\aieval8\examproctoring\entity'
output_path = r'D:\Mega Project 4th Year\AI-Exam-Proctoring-System\docs\audit\database-schema.md'

with open(schema_sql_path, 'r', encoding='utf-8') as f:
    sql_text = f.read()

# Entity mapping dictionary
entity_map = {
    'clients': 'Client.java',
    'users': 'User.java',
    'exams': 'Exam.java',
    'questions': 'Question.java',
    'coding_questions': 'CodingQuestion.java',
    'exam_enrollments': 'ExamEnrollment.java',
    'exam_attempts': 'ExamAttempt.java',
    'proctoring_sessions': 'ProctoringSession.java',
    'proctoring_events': 'ProctoringEvent.java',
    'cheating_logs': 'CheatingLogEntry.java',
    'notifications': 'Notification.java',
}

lines = []
lines.append("# Database Schema & JPA Entity Mapping Audit Inventory\n")
lines.append("Comprehensive inventory of all MySQL tables, columns, data types, nullability, default values, primary keys, foreign keys, indexes, and their corresponding Spring Boot JPA Entities.\n")

# Parse CREATE TABLE blocks
table_blocks = re.findall(r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)\s*\((.*?)\)\s*ENGINE', sql_text, re.DOTALL | re.IGNORECASE)

for table_name, body in table_blocks:
    entity_name = entity_map.get(table_name.lower(), 'N/A')
    lines.append(f"## Table: `{table_name}`")
    lines.append(f"**JPA Entity Mapping**: `{entity_name}`\n")
    lines.append("| Column Name | SQL Data Type | Nullable | Default Value | Key / Constraint / Index | JPA Field Mapping |")
    lines.append("|---|---|---|---|---|---|")

    # Extract columns and constraints
    items = body.strip().split('\n')
    col_rows = []
    constraints = []
    keys = []

    for raw_line in items:
        line = raw_line.strip().rstrip(',')
        if not line:
            continue
        if line.startswith('--') or line.startswith('#'):
            continue
        if re.match(r'^(PRIMARY\s+KEY|KEY|INDEX|UNIQUE\s+KEY|CONSTRAINT)', line, re.IGNORECASE):
            constraints.append(line)
        else:
            # Column definition
            m = re.match(r'^`?(\w+)`?\s+([A-Za-z0-9_()]+(?:\s+UNSIGNED)?)\s*(NOT\s+NULL|NULL)?\s*(AUTO_INCREMENT)?\s*(DEFAULT\s+[^,]+)?', line, re.IGNORECASE)
            if m:
                cname = m.group(1)
                ctype = m.group(2)
                cnull = "NO" if (m.group(3) and "NOT" in m.group(3).upper()) else "YES"
                cdef = m.group(5).replace('DEFAULT', '').strip() if m.group(5) else ("AUTO_INCREMENT" if m.group(4) else "None")
                
                # Check key status
                key_type = " "
                if cname.lower() == 'id':
                    key_type = "PK (Primary Key)"
                for c in constraints:
                    if f"({cname})" in c or f" {cname}," in c:
                        if "PRIMARY KEY" in c:
                            key_type = "PK"
                        elif "UNIQUE" in c:
                            key_type = "UK (Unique Key)"
                        elif "CONSTRAINT" in c and "FOREIGN KEY" in c:
                            key_type = "FK (Foreign Key)"
                        elif "KEY" in c or "INDEX" in c:
                            key_type = "Index"

                col_rows.append(f"| `{cname}` | `{ctype}` | {cnull} | `{cdef}` | {key_type} | `{cname}` |")
            else:
                col_rows.append(f"| `{line.split()[0]}` | `{line}` | - | - | - | - |")

    lines.extend(col_rows)
    lines.append("\n**Constraints & Indexes:**")
    for con in constraints:
        lines.append(f"- `{con}`")
    lines.append("\n---\n")

with open(output_path, 'w', encoding='utf-8') as out:
    out.write('\n'.join(lines))

print(f"Generated {len(lines)} lines in {output_path}")
