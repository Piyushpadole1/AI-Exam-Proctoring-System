import os
import re

dir_path = r'D:\Mega Project 4th Year\AI-Exam-Proctoring-System\backend-spring\src\main\java\com\aieval8\examproctoring\controller'
for fn in sorted(os.listdir(dir_path)):
    if not fn.endswith('.java'):
        continue
    fp = os.path.join(dir_path, fn)
    with open(fp, 'r', encoding='utf-8', errors='ignore') as f:
        text = f.read()

    base_match = re.search(r'@RequestMapping\(\s*\"([^\"]+)\"', text)
    base_url = base_match.group(1) if base_match else ''

    print(f'### Controller: {fn} (Base URL: "{base_url}")')
    pattern = r'@(GetMapping|PostMapping|PutMapping|DeleteMapping|PatchMapping|RequestMapping)\((.*?)\)\s*(?:@.*?\s*)*(?:public|private|protected)\s+([^\s]+)\s+([a-zA-Z0-9_]+)\s*\((.*?)\)'
    for m in re.finditer(pattern, text, re.DOTALL):
        verb = m.group(1)
        args = m.group(2).strip().replace('\n', ' ')
        ret = m.group(3)
        name = m.group(4)
        params = m.group(5).strip().replace('\n', ' ')
        params = re.sub(r'\s+', ' ', params)
        print(f'- [{verb}] {args} -> {name}({params}) : {ret}')
    print()
